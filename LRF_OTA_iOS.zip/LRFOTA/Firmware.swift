//
//  Firmware.swift
//  LRF OTA Updater (iOS)
//
//  固件镜像解析 —— 与安卓 Firmware.kt 逐条对应。
//
//  把 Intel HEX 和原始 BIN 统一解析成一段连续内存 [base, base+bytes.count)，
//  中间的空洞用 0xFF 填满（Flash 擦除后的值，写进去等于没写）。
//
//  ★ BIN 有两种，必须分清（分不清就是"OTA 完开机还是旧程序"的根因）：
//    1. 纯 APP 镜像：第一字节就是 APP 入口（j handle_reset，0x6F 1x ..），
//       应按 0x1000 起始写入；
//    2. WCH_AssemblingFileTool 合出来的整片镜像：0x0 放 JumpIAP
//       （6F C0 03 00）或 0x00 填充，0x1000 才是 APP，后面还跟着 IAP。
//       这种必须先截取 [0x1000, 0x3C000) 再写。
//

import Foundation

struct Firmware {

    static let appStart = 0x1000          // Image A 起点（APP 链接地址）
    static let appLimit = 0x3C000         // Image A 上限（IAP 的擦除检查只允许到 0x3C000）

    /// WCH_AssemblingFileTool 整片镜像的标志：0x0 处的 `jal 0x3C000`
    private static let jumpIap: [UInt8] = [0x6F, 0xC0, 0x03, 0x00]

    let name: String
    let base: Int
    let bytes: [UInt8]
    let source: String        // "HEX" / "HEX (APP region only)" / "BIN" / "BIN (full-chip -> APP region)"
    let iapNote: String       // 整片镜像里 IAP 区的体检结论

    var end: Int { base + bytes.count }
    var size: Int { bytes.count }

    /// 镜像 CRC32 —— 升级前打在日志里，两次一对比就知道发的到底是不是新文件
    var crc32: UInt32 { CRC32.checksum(bytes) }

    /// APP 入口 4 字节（0x1000 处的 j handle_reset）
    var entry: String {
        guard bytes.count >= 4 else { return "--" }
        return String(format: "%02X %02X %02X %02X", bytes[0], bytes[1], bytes[2], bytes[3])
    }

    /// 镜像里 0x1004 的 Image_Flag（手机端判文件有效性用的字段）
    var imageFlag: UInt32 {
        guard bytes.count >= 8 else { return 0 }
        return bytes.le32(4)
    }

    /// 是否落在可写区间
    var inAppRegion: Bool { base >= Firmware.appStart && end <= Firmware.appLimit }

    // MARK: - 载入

    static func load(url: URL) throws -> Firmware {
        let raw = try readBytes(url: url)
        guard !raw.isEmpty else { throw OtaError("File is empty") }
        let fname = url.lastPathComponent
        return looksLikeHex(raw) ? try parseHex(raw, fname) : try fromBin(raw, fname)
    }

    /// 读取文件。iOS 的 fileImporter 给的是安全作用域 URL，必须成对
    /// start/stop，否则 iCloud 或其它 App 目录里的文件读不出来。
    private static func readBytes(url: URL) throws -> [UInt8] {
        let scoped = url.startAccessingSecurityScopedResource()
        defer { if scoped { url.stopAccessingSecurityScopedResource() } }
        do {
            let d = try Data(contentsOf: url)
            return [UInt8](d)
        } catch {
            throw OtaError("Cannot open this file (\(error.localizedDescription))")
        }
    }

    private static func looksLikeHex(_ b: [UInt8]) -> Bool {
        var i = 0
        // 跳过 UTF-8 BOM 与空白
        if b.count >= 3 && b[0] == 0xEF && b[1] == 0xBB && b[2] == 0xBF { i = 3 }
        while i < b.count && (b[i] == 0x20 || b[i] == 0x0D || b[i] == 0x0A || b[i] == 0x09) { i += 1 }
        return i < b.count && b[i] == UInt8(ascii: ":")
    }

    /// 整片镜像的判别：要么带 JumpIAP 特征，要么头 4 KB 是填充且 0x1000 有内容
    private static func isFullChipImage(_ raw: [UInt8]) -> Bool {
        if raw.count >= 4 && Array(raw[0 ..< 4]) == jumpIap { return true }
        if raw.count < appStart + 4 { return false }
        for i in 0 ..< appStart {
            let v = raw[i]
            if v != 0x00 && v != 0xFF { return false }   // 头 4 KB 有真代码 → 不是整片
        }
        // 头 4 KB 全是填充：看 0x1000 处像不像 APP 入口（j / jal 的操作码段）
        let e = raw[appStart]
        return e == 0x6F || e == 0x2F || e == 0xEF
    }

    /// 去掉结尾的 0xFF（擦除态，写不写都一样），少擦少写少传
    private static func trimTailFF(_ b: [UInt8]) -> [UInt8] {
        var n = b.count
        while n > 1 && b[n - 1] == 0xFF { n -= 1 }
        return Array(b[0 ..< n])
    }

    /// 整片镜像里 0x3C000 处的 IAP 入口体检
    private static func iapCheck(_ raw: [UInt8]) -> String {
        if raw.count < appLimit + 4 { return "Image has no IAP region (short full-chip)" }
        let e = Array(raw[appLimit ..< appLimit + 4])
        let s = String(format: "%02X %02X %02X %02X", e[0], e[1], e[2], e[3])
        if e == [0x6F, 0x00, 0x40, 0x7B] {
            return "Full-chip image carries the new IAP (\(s), matching)"
        }
        if e == [0x6F, 0x00, 0xC0, 0x76] {
            return "WARNING: full-chip image carries the old 2024 IAP (\(s)) - OTA never writes this region, "
                + "but flashing it over USB puts the device back into the 'cannot enter OTA' state; "
                + "repair it with the repair build first"
        }
        return "Full-chip image IAP entry \(s) (unknown version)"
    }

    private static func fromBin(_ raw: [UInt8], _ name: String) throws -> Firmware {
        guard isFullChipImage(raw) else {
            // 纯 APP 镜像：默认按 APP 起始地址 0x1000 放
            return Firmware(name: name, base: appStart, bytes: trimTailFF(raw), source: "BIN", iapNote: "")
        }
        // 整片镜像：只取 APP 区，IAP / 0x40000 库区绝对不能动
        let end = min(raw.count, appLimit)
        if end <= appStart { throw OtaError("This full-chip bin has no APP region") }
        let img = trimTailFF(Array(raw[appStart ..< end]))
        if img.isEmpty { throw OtaError("APP region is empty") }
        return Firmware(name: name, base: appStart, bytes: img,
                        source: "BIN (full-chip -> APP region)", iapNote: iapCheck(raw))
    }

    private static func parseHex(_ raw: [UInt8], _ name: String) throws -> Firmware {
        let text = String(decoding: raw, as: UTF8.self)
        var base = 0
        var minA = Int.max
        var maxA = 0
        var pieces: [(Int, [UInt8])] = []

        let lines = text.split(whereSeparator: { $0 == "\n" || $0 == "\r" })
        for lineRaw in lines {
            // Substring 没有 trimmingCharacters，先转 String
            let line = String(lineRaw).trimmingCharacters(in: .whitespaces)
            if line.count < 11 || !line.hasPrefix(":") { continue }
            guard let rec = hexToBytes(line), rec.count >= 5 else { continue }
            let len = Int(rec[0])
            let addr = (Int(rec[1]) << 8) | Int(rec[2])
            let type = Int(rec[3])

            if type == 0x01 { break }                      // EOF
            if type == 0x02 {                              // 扩展段地址
                if rec.count >= 6 { base = ((Int(rec[4]) << 8) | Int(rec[5])) << 4 }
                continue
            }
            if type == 0x04 {                              // 扩展线性地址
                if rec.count >= 6 { base = ((Int(rec[4]) << 8) | Int(rec[5])) << 16 }
                continue
            }
            if type != 0x00 { continue }                   // 03 / 05 起始地址，忽略
            if len == 0 || 4 + len > rec.count { continue }

            let abs = base + addr
            let d = Array(rec[4 ..< (4 + len)])
            pieces.append((abs, d))
            if abs < minA { minA = abs }
            if abs + len > maxA { maxA = abs + len }
        }

        guard !pieces.isEmpty, minA != Int.max, maxA > minA else {
            throw OtaError("No valid address record in the HEX file")
        }

        var img = [UInt8](repeating: 0xFF, count: maxA - minA)
        for (a, d) in pieces {
            let off = a - minA
            if off >= 0 && off + d.count <= img.count {
                img.replaceSubrange(off ..< (off + d.count), with: d)
            }
        }

        /* MRS 有时会把 0x40000 的 BLE 库区一起打进 hex；机器上本来就有，
           IAP 也只允许写 0x1000~0x3C000 —— 自动截取 APP 区。 */
        var lo = minA
        var hi = maxA
        var note = "HEX"
        if lo < appStart || hi > appLimit {
            if lo < appStart { lo = appStart }
            if hi > appLimit { hi = appLimit }
            if hi <= lo {
                throw OtaError(String(format: "HEX 0x%X~0x%X has no data inside the APP region (0x%X~0x%X)",
                                      minA, maxA, appStart, appLimit))
            }
            note = "HEX (APP region only)"
        }
        let slice = trimTailFF(Array(img[(lo - minA) ..< (hi - minA)]))
        if slice.isEmpty { throw OtaError("APP region is empty after slicing") }
        return Firmware(name: name, base: lo, bytes: slice, source: note, iapNote: "")
    }

    /// 解析 ":10AABB00...." 这一行，从冒号后面开始，每个字节两位。
    /// 校验和也一起读进来（安卓端同样读，越界判断靠 rec.count）。
    private static func hexToBytes(_ s: String) -> [UInt8]? {
        let chars = Array(s.dropFirst())
        if chars.count < 2 { return nil }
        var out: [UInt8] = []
        out.reserveCapacity(chars.count / 2)
        var i = 0
        while i + 1 < chars.count {
            guard let hi = chars[i].hexDigitValue, let lo = chars[i + 1].hexDigitValue else { return nil }
            out.append(UInt8((hi << 4) | lo))
            i += 2
        }
        return out
    }
}
